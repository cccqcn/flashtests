#include <stdio.h>
#include "jpeglib.h"
#include "cdjpeg.h"
#include "AS3.h"
#include <stdlib.h>

int imageWidth;
int imageHeight;
int numComponents;
int colorComponents;
unsigned char *image;

int read_jpeg_file( char *filename )
{
	struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	
	FILE *infile = fopen( filename, "rb" );
	
	if ( !infile )
	{
		printf("Error opening jpeg file %s\n!", filename );
		return -1;
	}
	
	cinfo.err = jpeg_std_error( &jerr );
	jpeg_create_decompress( &cinfo );
	jpeg_stdio_src( &cinfo, infile );
	jpeg_read_header( &cinfo, TRUE );
	jpeg_start_decompress(&cinfo);
	
	// storing variables
	imageWidth = cinfo.image_width;
	imageHeight = cinfo.image_height;
	numComponents =  cinfo.num_components;
	colorComponents = cinfo.out_color_components;
	
	/* allocate data and read the image as RGBRGBRGBRGB */
	image = malloc(cinfo.output_width * cinfo.output_height * 3);
	int lng = cinfo.output_height;
	int i = 0;
	
	for(i=0; i < lng; i++)
	{
		unsigned char * ptr = image + i * 3 * cinfo.output_width;
		jpeg_read_scanlines(&cinfo, &ptr, 1);
	}
	
	(void) jpeg_finish_decompress(&cinfo);
	jpeg_destroy_decompress(&cinfo);
	
	return AS3_Int(1);
}

static AS3_Val parseJPG( void *self, AS3_Val args )
{
	char * fileName;
	AS3_ArrayValue(args, "StrType", &fileName);
	read_jpeg_file( fileName );
	return AS3_Array("IntType, IntType, IntType, IntType, IntType", imageWidth, imageHeight, numComponents, colorComponents, (int)image);
}

int main()
{
	AS3_Val parseJPGAlias = AS3_Function( NULL, parseJPG);
	AS3_Val result = AS3_Object( "parseJPG:AS3ValType", parseJPGAlias );
	AS3_Release( parseJPGAlias );
	AS3_LibInit( result );
	return 0;	
}

